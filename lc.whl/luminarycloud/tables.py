# Copyright 2024 Luminary Cloud, Inc. All Rights Reserved.
class RectilinearTable:
    pass
